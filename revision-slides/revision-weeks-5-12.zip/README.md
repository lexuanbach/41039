# Programming 1 — revision Weeks 5–12

Eight hand-written revision decks in the established HCMUT format, shown at the start of
the next lecture. Weeks 6–12 each have an overview slide, a one-slide summary of the week,
then ten questions answered on the next click: 1 fill in the blanks, 2 multiple choice,
2 predict the output, 2 find the bug (Java and Python) and 3 write the code from a skeleton,
followed by a bridge to the next lecture and a checklist. Week 7 adds four linked-list
questions (Q11–Q14: two predict the output, two find the bug). Week 5 uses an earlier mix of
ten short questions and three coding questions.

Each `revision-slides/revision-week-N/` folder holds the editable `.tex`, the compiled PDF,
the logo, a README (question table and verification notes), and complete runnable programs
for every slide: `examples/` (with the intentionally faulty files at the slides' line
numbers), `solutions/`, `starters/` and `checks.json` (every recorded run).

Verify every recorded run from the repository root (Python 3 and a JDK; set `JAVA_BIN` and
`JAVAC_BIN` if needed):

    python3 scripts/check_revision_slides.py

Compile a deck by running XeLaTeX twice in its folder. Current Canvas instructions govern
assessment.
