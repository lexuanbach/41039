class Player:
    def __init__(self, name, points):
        self.name = name
        self.points = points
        self.history = []
    def add(self, n):
        self.points += n
        self.history.append(n)
    def __str__(self):
        return self.name + ": " + str(self.points)
an, binh = Player("An", 0), Player("Binh", 5)
an.add(3)
an.add(4)
print(an)
print(binh.history)
